import 'server-only';

import {
  cache,
} from 'react';

import {
  createClient,
} from '@/lib/supabase/server';

import type {
  NormalizedUnitOfferingImportRow,
  UnitOfferingImportBatch,
  UnitOfferingImportStagedRow,
} from './types';

interface ImportBatchRow {
  id: string;
  entity_type: 'unit_offerings';
  template_version: string;
  original_file_name: string;
  file_size_bytes: number | null;

  status:
    UnitOfferingImportBatch['status'];

  total_rows: number;
  valid_rows: number;
  invalid_rows: number;
  duplicate_rows: number;
  imported_rows: number;
  skipped_rows: number;
  failed_rows: number;

  failure_message: string | null;

  import_options:
    Record<string, unknown> | null;

  validation_summary:
    Record<string, unknown> | null;

  created_at: string;
  completed_at: string | null;
}

interface ImportStagedRow {
  id: string;
  source_row_number: number;

  status:
    UnitOfferingImportStagedRow['status'];

  source_data:
    Record<string, unknown> | null;

  normalized_data:
    Record<string, unknown> | null;

  field_errors:
    Record<string, string[]> | null;

  row_errors:
    string[] | null;

  duplicate_key: string | null;
  imported_record_id: string | null;
}

function mapBatch(
  row: ImportBatchRow,
): UnitOfferingImportBatch {
  return {
    id: row.id,
    entityType: row.entity_type,
    templateVersion:
      row.template_version,
    originalFileName:
      row.original_file_name,
    fileSizeBytes:
      row.file_size_bytes,

    status: row.status,

    totalRows: row.total_rows,
    validRows: row.valid_rows,
    invalidRows: row.invalid_rows,
    duplicateRows:
      row.duplicate_rows,
    importedRows:
      row.imported_rows,
    skippedRows:
      row.skipped_rows,
    failedRows:
      row.failed_rows,

    failureMessage:
      row.failure_message,

    importOptions:
      row.import_options ?? {},

    validationSummary:
      row.validation_summary ?? {},

    createdAt: row.created_at,
    completedAt:
      row.completed_at,
  };
}

function isNormalizedUnitOfferingImportRow(
  value: unknown,
): value is NormalizedUnitOfferingImportRow {
  if (
    typeof value !== 'object' ||
    value === null ||
    Array.isArray(value)
  ) {
    return false;
  }

  const candidate =
    value as Record<string, unknown>;

  return (
    typeof candidate.academicPeriod ===
      'string' &&
    typeof candidate.programmeName ===
      'string' &&
    typeof candidate.cohortName ===
      'string' &&
    typeof candidate.unitName ===
      'string' &&
    typeof candidate.offeringType ===
      'string' &&
    typeof candidate.weeklySessions ===
      'number' &&
    typeof candidate.sessionDurationMinutes ===
      'number' &&
    typeof candidate.timetableEnabled ===
      'boolean' &&
    typeof candidate.status ===
      'string'
  );
}
function mapStagedRow(
  row: ImportStagedRow,
): UnitOfferingImportStagedRow {
  return {
    id: row.id,
    sourceRowNumber:
      row.source_row_number,

    status: row.status,

    sourceData:
      row.source_data ?? {},

    normalizedData:
      row.normalized_data &&
      isNormalizedUnitOfferingImportRow(
        row.normalized_data,
      )
        ? row.normalized_data
        : {},

    fieldErrors:
      row.field_errors ?? {},

    rowErrors:
      row.row_errors ?? [],

    duplicateKey:
      row.duplicate_key,

    importedRecordId:
      row.imported_record_id,
  };
}

export const getUnitOfferingImportBatch =
  cache(
    async (
      batchId: string,
    ): Promise<{
      batch:
        UnitOfferingImportBatch;

      rows:
        UnitOfferingImportStagedRow[];
    } | null> => {
      const supabase =
        await createClient();

      const {
        data: batchData,
        error: batchError,
      } = await supabase
        .from('import_batches')
        .select(`
          id,
          entity_type,
          template_version,
          original_file_name,
          file_size_bytes,
          status,
          total_rows,
          valid_rows,
          invalid_rows,
          duplicate_rows,
          imported_rows,
          skipped_rows,
          failed_rows,
          failure_message,
          import_options,
          validation_summary,
          created_at,
          completed_at
        `)
        .eq('id', batchId)
        .eq(
          'entity_type',
          'unit_offerings',
        )
        .maybeSingle();

      if (batchError) {
        throw new Error(
          `Unable to load the Units on Offer import batch: ${batchError.message}`,
        );
      }

      if (!batchData) {
        return null;
      }

      const {
        data: rowData,
        error: rowError,
      } = await supabase
        .from('import_rows')
        .select(`
          id,
          source_row_number,
          status,
          source_data,
          normalized_data,
          field_errors,
          row_errors,
          duplicate_key,
          imported_record_id
        `)
        .eq(
          'import_batch_id',
          batchId,
        )
        .order(
          'source_row_number',
          {
            ascending: true,
          },
        );

      if (rowError) {
        throw new Error(
          `Unable to load the staged Units on Offer rows: ${rowError.message}`,
        );
      }

      return {
        batch:
          mapBatch(
            batchData as
              ImportBatchRow,
          ),

        rows:
          (
            (
              rowData ?? []
            ) as ImportStagedRow[]
          ).map(mapStagedRow),
      };
    },
  );